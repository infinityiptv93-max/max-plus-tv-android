# Max Plus TV — app Android (protótipo funcional)

Aplicativo Android nativo em Kotlin/Jetpack Compose para importar uma playlist M3U autorizada por arquivo ou link e selecionar seus canais para reprodução usando AndroidX Media3/ExoPlayer.

## Importação e uso

- **Arquivo:** toque em “Abrir arquivo M3U” e selecione a playlist no seletor de arquivos do Android. O app lê o conteúdo selecionado diretamente; não copia nem envia o arquivo ao GitHub.
- **Link:** cole o endereço HTTPS completo e toque em “Importar link”. Redirecionamentos só são seguidos enquanto continuarem em HTTPS (até cinco).
- A lista aceita até **2 MB** e **5.000 canais**. O app mostra os canais encontrados; toque em um para iniciar a reprodução.
- Para uma lista atualizada, importe-a novamente. “Remover lista” apaga a cópia local.

## Privacidade e limitações

- A lista e os endereços dos canais ficam em JSON no armazenamento privado interno do app. Não são enviados ao GitHub nem a um servidor do projeto. O arquivo é privado no sandbox Android, mas não é criptografado pelo app; desinstalar o aplicativo remove esses dados. Backup Android está desabilitado para o app.
- Links da playlist e canais precisam ser HTTPS. O aplicativo não aceita HTTP nem tenta contornar bloqueios de rede. O provedor da playlist ainda recebe a solicitação feita ao importar um link.
- O app não fornece conteúdo, credenciais, listas, canais ou serviço de streaming. Use somente material para o qual você tem autorização.
- A reprodução depende do formato e das regras do provedor. HLS (`.m3u8`) recebe indicação explícita ao player; outros formatos diretos dependem do suporte Media3/dispositivo. DRM, login avançado, cookies, cabeçalhos especiais, formatos proprietários e EPG não estão implementados. Um canal carregado na lista pode ainda falhar ao reproduzir.
- Esta é uma primeira versão: não foi verificada em uma compilação Android local neste pacote. O APK precisa ser gerado pelo workflow do GitHub Actions; o APK de depuração serve para teste, não é uma versão assinada para publicação na Play Store.

## Compilação pelo GitHub Actions

O workflow `.github/workflows/build.yml`, guardado separadamente no repositório, valida e extrai `MinhaIPTV_Android.zip`, compila `assembleDebug` com Java 17, Gradle 8.9 e Android SDK 35, e publica `app-debug.apk` como artefato. As playlists pessoais não devem ser colocadas no ZIP nem no repositório.

## Configuração do projeto

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (usado no workflow)
- Kotlin: 2.0.21; Java/Kotlin JVM target: 17
- Android compile/target SDK: 35; min SDK: 23
- Pacote: `com.minhaiptv.app`
