package com.minhaiptv.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URI
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale

private val Red = Color(0xFFF20D19)
private val Background = Color(0xFF090909)
private val Panel = Color(0xFF151719)
private val Muted = Color(0xFF9CA0A5)
private const val PLAYLIST_FILENAME = "channels_m3u.json"
private const val MAX_PLAYLIST_BYTES = 2 * 1024 * 1024
private const val MAX_CHANNELS = 5000

private data class Channel(
    val name: String,
    val url: String,
    val group: String = "Sem categoria"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Background,
                    surface = Panel,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                MinhaIPTVApp()
            }
        }
    }
}

@Composable
private fun MinhaIPTVApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val player = remember(context) { ExoPlayer.Builder(context.applicationContext).build() }
    var channels by remember { mutableStateOf(loadSavedChannels(context)) }
    var selectedIndex by remember { mutableIntStateOf(-1) }
    var playlistUrl by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Importe uma lista M3U autorizada para começar") }

    DisposableEffect(player, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) player.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.release()
        }
    }

    fun applyPlaylist(loaded: List<Channel>, sourceLabel: String) {
        try {
            saveChannels(context, loaded)
            channels = loaded
            selectedIndex = -1
            player.stop()
            notice = "${loaded.size} canais carregados de $sourceLabel"
        } catch (error: Exception) {
            notice = error.message ?: "Não foi possível guardar a lista neste aparelho"
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isLoading = true
                notice = "Lendo arquivo M3U…"
                try {
                    val loaded = withContext(Dispatchers.IO) {
                        val input = context.contentResolver.openInputStream(uri)
                            ?: error("Não consegui abrir esse arquivo")
                        input.use { stream ->
                            parseM3u(String(readLimited(stream), StandardCharsets.UTF_8))
                        }
                    }
                    applyPlaylist(loaded, "arquivo")
                } catch (error: Exception) {
                    notice = error.message ?: "Não foi possível ler essa lista M3U"
                } finally {
                    isLoading = false
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF260407), Background, Background))
            )
            .systemBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Header(
            onSearch = { notice = "Use o campo HTTPS para carregar uma lista M3U" },
            onSettings = { notice = "A lista é guardada apenas neste aparelho" }
        )

        Spacer(Modifier.height(6.dp))

        ImportPanel(
            url = playlistUrl,
            loading = isLoading,
            hasChannels = channels.isNotEmpty(),
            onUrlChange = { playlistUrl = it },
            onChooseFile = { filePicker.launch(arrayOf("*/*")) },
            onImportUrl = {
                val source = playlistUrl.trim()
                if (source.isBlank()) {
                    notice = "Cole o endereço HTTPS da lista M3U"
                } else {
                    scope.launch {
                        isLoading = true
                        notice = "Baixando lista M3U…"
                        try {
                            val loaded = withContext(Dispatchers.IO) {
                                val text = downloadPlaylist(source)
                                parseM3u(text)
                            }
                            applyPlaylist(loaded, "link")
                        } catch (error: Exception) {
                            notice = error.message ?: "Não foi possível carregar o link M3U"
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onClear = {
                player.stop()
                channels = emptyList()
                selectedIndex = -1
                context.deleteFile(PLAYLIST_FILENAME)
                notice = "Lista removida deste aparelho"
            }
        )

        Spacer(Modifier.height(8.dp))

        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (maxWidth >= 700.dp) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ChannelSidebar(
                        channels = channels,
                        selectedIndex = selectedIndex,
                        onSelect = { index ->
                            selectedIndex = index
                            player.setMediaItem(mediaItemFor(channels[index].url))
                            player.prepare()
                            player.play()
                            notice = "Reproduzindo: ${channels[index].name}"
                        },
                        modifier = Modifier
                            .widthIn(min = 190.dp, max = 270.dp)
                            .fillMaxHeight()
                    )
                    PlayerPane(
                        player = player,
                        selected = channels.getOrNull(selectedIndex),
                        notice = notice,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    PlayerPane(
                        player = player,
                        selected = channels.getOrNull(selectedIndex),
                        notice = notice,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 270.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Canais (${channels.size})",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 5.dp)
                    )
                    if (channels.isEmpty()) {
                        Text(
                            "Escolha um arquivo M3U ou importe um link acima.",
                            color = Muted,
                            fontSize = 12.sp
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentPadding = PaddingValues(bottom = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            itemsIndexed(channels) { index, channel ->
                                ChannelRow(
                                    channel = channel,
                                    selected = index == selectedIndex,
                                    onClick = {
                                        selectedIndex = index
                                        player.setMediaItem(mediaItemFor(channel.url))
                                        player.prepare()
                                        player.play()
                                        notice = "Reproduzindo: ${channel.name}"
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        Text(
            text = notice,
            color = Muted,
            fontSize = 11.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().padding(top = 5.dp, start = 3.dp)
        )
    }
}

@Composable
private fun Header(onSearch: () -> Unit, onSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(54.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "▶ MAX PLUS TV",
            color = Red,
            fontSize = 19.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSearch) {
            Icon(Icons.Default.Search, contentDescription = "Ajuda para pesquisa", tint = Color.White)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Privacidade da lista", tint = Color.White)
        }
    }
}

@Composable
private fun ImportPanel(
    url: String,
    loading: Boolean,
    hasChannels: Boolean,
    onUrlChange: (String) -> Unit,
    onChooseFile: () -> Unit,
    onImportUrl: () -> Unit,
    onClear: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF101214))
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text("Adicionar lista M3U", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = url,
            onValueChange = onUrlChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            enabled = !loading,
            label = { Text("Link HTTPS da lista") },
            placeholder = { Text("https://exemplo.com/lista.m3u") }
        )
        Spacer(Modifier.height(5.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onImportUrl,
                enabled = !loading && url.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Red),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 7.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text("Importar link", fontSize = 12.sp)
            }
            TextButton(onClick = onChooseFile, enabled = !loading) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Abrir arquivo M3U", fontSize = 12.sp)
            }
            if (hasChannels) {
                TextButton(onClick = onClear, enabled = !loading) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = Red)
                    Text("Remover lista", color = Red, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ChannelSidebar(
    channels: List<Channel>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF101214))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF30090D))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.LiveTv, contentDescription = null, tint = Red)
            Spacer(Modifier.width(8.dp))
            Text("Canais (${channels.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        if (channels.isEmpty()) {
            Text(
                "Importe uma lista M3U acima.",
                color = Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(12.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(7.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                itemsIndexed(channels) { index, channel ->
                    ChannelRow(
                        channel = channel,
                        selected = index == selectedIndex,
                        onClick = { onSelect(index) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelRow(channel: Channel, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Red else Panel)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                channel.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (channel.group.isNotBlank()) {
                Text(
                    channel.group,
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir ${channel.name}", tint = Color.White)
    }
}

@Composable
private fun PlayerPane(
    player: ExoPlayer,
    selected: Channel?,
    notice: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF101214))
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LiveTv, contentDescription = null, tint = Red)
            Spacer(Modifier.width(7.dp))
            Text(
                selected?.name ?: "Reprodutor",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.height(7.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(9.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { viewContext ->
                    PlayerView(viewContext).apply {
                        useController = true
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        this.player = player
                    }
                },
                update = { view -> view.player = player }
            )
            if (selected == null) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Red,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        if (notice.startsWith("Importe")) "Importe sua lista M3U para começar" else "Escolha um canal da lista",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }
        }
        if (selected != null) {
            Text(
                text = selected.group,
                color = Muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
    }
}

private fun mediaItemFor(address: String): MediaItem {
    val builder = MediaItem.Builder().setUri(address)
    val path = address.substringBefore('?').substringBefore('#')
    if (path.endsWith(".m3u8", ignoreCase = true)) {
        builder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_M3U8)
    }
    return builder.build()
}

private fun parseM3u(text: String): List<Channel> {
    val cleanText = text.removePrefix("\uFEFF")
    val result = mutableListOf<Channel>()
    var pendingName: String? = null
    var pendingGroup = "Sem categoria"

    for (rawLine in cleanText.lineSequence()) {
        val line = rawLine.trim()
        if (line.isEmpty()) continue

        if (line.startsWith("#EXTINF", ignoreCase = true)) {
            val metadata = line.substringAfter(':', "")
            val nameAfterComma = metadata.substringAfter(',', "").trim()
            val tvgName = Regex("""tvg-name=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(metadata)?.groupValues?.getOrNull(1)
            pendingName = nameAfterComma.ifBlank { tvgName ?: "Canal ${result.size + 1}" }
            pendingGroup = Regex("""group-title=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(metadata)?.groupValues?.getOrNull(1)?.ifBlank { "Sem categoria" }
                ?: "Sem categoria"
        } else if (!line.startsWith('#')) {
            val mediaUri = try {
                URI(line)
            } catch (_: Exception) {
                throw IllegalArgumentException("Encontrei um endereço de canal inválido")
            }
            if (!mediaUri.scheme.equals("https", ignoreCase = true) || mediaUri.host.isNullOrBlank()) {
                throw IllegalArgumentException(
                    "Esta versão aceita canais HTTPS para proteger seus dados. A lista contém um endereço não HTTPS."
                )
            }
            if (result.size >= MAX_CHANNELS) {
                throw IllegalArgumentException("A lista tem mais de 5.000 canais; reduza o tamanho e tente novamente.")
            }
            val name = pendingName ?: nameFromUrl(line, result.size + 1)
            result += Channel(name = name, url = line, group = pendingGroup)
            pendingName = null
            pendingGroup = "Sem categoria"
        }
    }

    if (result.isEmpty()) {
        throw IllegalArgumentException("Não encontrei canais nessa lista. Confira se o arquivo é M3U válido.")
    }
    if (result.size > MAX_CHANNELS) {
        throw IllegalArgumentException("A lista tem mais de 5.000 canais; reduza o tamanho e tente novamente.")
    }
    return result
}

private fun nameFromUrl(value: String, index: Int): String {
    return try {
        val path = URI(value).path.orEmpty().substringAfterLast('/').substringBeforeLast('.')
        path.takeIf { it.isNotBlank() } ?: "Canal $index"
    } catch (_: Exception) {
        "Canal $index"
    }
}

private fun downloadPlaylist(address: String): String {
    var current = try {
        URI(address)
    } catch (_: Exception) {
        throw IllegalArgumentException("O endereço do link não é válido")
    }

    repeat(6) { redirectCount ->
        if (!current.scheme.equals("https", ignoreCase = true) || current.host.isNullOrBlank()) {
            throw IllegalArgumentException("Por segurança, use apenas links HTTPS válidos")
        }
        val connection = current.toURL().openConnection() as? javax.net.ssl.HttpsURLConnection
            ?: throw IllegalArgumentException("O endereço precisa usar HTTPS")
        connection.instanceFollowRedirects = false
        connection.connectTimeout = 15_000
        connection.readTimeout = 20_000
        connection.setRequestProperty("User-Agent", "MaxPlusTV/0.2 Android")
        try {
            val status = connection.responseCode
            if (status in 300..399) {
                val location = connection.getHeaderField("Location")
                    ?: throw IllegalArgumentException("O servidor redirecionou sem informar outro endereço")
                current = current.resolve(location)
                if (redirectCount == 5) {
                    throw IllegalArgumentException("O link redirecionou muitas vezes")
                }
            } else {
                if (status !in 200..299) {
                    throw IllegalArgumentException("O servidor respondeu com erro HTTP $status")
                }
                connection.inputStream.use { input ->
                    return String(readLimited(input), StandardCharsets.UTF_8)
                }
            }
        } finally {
            connection.disconnect()
        }
    }
    throw IllegalArgumentException("Não foi possível seguir o redirecionamento HTTPS")
}

private fun readLimited(input: java.io.InputStream): ByteArray {
    val out = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        if (out.size() + count > MAX_PLAYLIST_BYTES) {
            throw IllegalArgumentException("A lista ultrapassa o limite de 2 MB")
        }
        out.write(buffer, 0, count)
    }
    return out.toByteArray()
}

private fun saveChannels(context: android.content.Context, channels: List<Channel>) {
    val array = JSONArray()
    channels.forEach { channel ->
        array.put(
            JSONObject()
                .put("name", channel.name)
                .put("url", channel.url)
                .put("group", channel.group)
        )
    }
    context.openFileOutput(PLAYLIST_FILENAME, android.content.Context.MODE_PRIVATE).use { output ->
        output.write(array.toString().toByteArray(StandardCharsets.UTF_8))
    }
}

private fun loadSavedChannels(context: android.content.Context): List<Channel> {
    return try {
        val file = context.getFileStreamPath(PLAYLIST_FILENAME)
        if (!file.exists() || file.length() > MAX_PLAYLIST_BYTES * 2L) return emptyList()
        val stored = context.openFileInput(PLAYLIST_FILENAME).use { input ->
            String(input.readBytes(), StandardCharsets.UTF_8)
        }
        val array = JSONArray(stored)
        buildList {
            for (index in 0 until array.length().coerceAtMost(MAX_CHANNELS)) {
                val item = array.getJSONObject(index)
                val url = item.optString("url")
                if (url.startsWith("https://", ignoreCase = true)) {
                    add(
                        Channel(
                            name = item.optString("name", "Canal ${index + 1}"),
                            url = url,
                            group = item.optString("group", "Sem categoria")
                        )
                    )
                }
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}
