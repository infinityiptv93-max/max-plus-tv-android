# Max Plus TV — protótipo Android

Protótipo nativo em Kotlin + Jetpack Compose, com interface escura em vermelho/preto, categorias e canais demonstrativos.

## Compilação pelo GitHub Actions
Este projeto é empacotado como `MinhaIPTV_Android.zip`. Um workflow do GitHub deve extrair esse ZIP, compilar o APK de depuração e disponibilizá-lo como artefato da execução do workflow.

## Escopo atual
Esta versão é somente a interface demonstrativa. Ainda não reproduz vídeos, não importa listas M3U e não autentica em serviços. Use somente fontes e conteúdo que você tenha autorização para acessar.

## Dados de compilação
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Java: 17
- Android SDK: 35
- Pacote: `com.minhaiptv.app`
